<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGoodsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('goods', function (Blueprint $table) {
            $table->increments('id');
            $table->string('good_name',128);
            $table->Integer('numbers');
            $table->bigInteger('price');
            $table->string('description',256);
            $table->float('how_old'); //1~9.9
            $table->foreign('seller_id')->references('id')->on('sellers');
            $table->datetime('create_at');
            $table->datetime('update_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('goods');
    }
}
